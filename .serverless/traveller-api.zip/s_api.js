
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'anukesh369',
  applicationName: 'projectlive-api',
  appUid: 'btz0QmG82lgmDFpDp4',
  orgUid: 'b7eb2e79-5e6b-434c-8708-fdf3b3ff605d',
  deploymentUid: 'c1694a88-1c3d-4f2a-96d3-44c5ffb024a2',
  serviceName: 'traveller-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'traveller-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}